import json
import tkinter as tk
import sys
from tkinter import ttk
import subprocess  # Added for calling another script

class LengthsLoader:
    def __init__(self, file_name):
        self.file_name = file_name

    def read_lengths(self):
        try:
            with open(self.file_name, 'r') as file:
                lengths = json.load(file)
            return lengths.get("Header", {}), lengths.get("TransactionRecord", {}), lengths.get("TrailerRecord", {})
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            raise
        except FileNotFoundError:
            print(f"Error: File {self.file_name} not found.")
            raise
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
            raise

def save_file_name(file_name):
    with open("filename.txt", "w") as file:
        file.write(file_name)

def generate_file(file_type, root):
    if file_type == "QPAY":
        file_name = 'QPAY_Lengths.json'
    elif file_type == "QDOI":
        file_name = 'QDOI_Lengths.json'
    elif file_type == "MCOH":
        file_name = 'MCOH_Lengths.json'    
    elif file_type == "QCNI":
        file_name = 'QCNI_Lengths.json'
    elif file_type == "QREV":
        file_name = 'QREV_Lengths.json'
    elif file_type == "QDOE":
        file_name = 'QDOE_Lengths.json'            
    else:
        print("Invalid file type selected.")
        return

    lengths_loader = LengthsLoader(file_name)
   
    
    # Perform any further processing with the desired lengths
    
    print(f"Generated File: {file_name}")
    
    # Save the file_name to filename.txt
    save_file_name(file_name)
    
    subprocess.run(['python', 'StubFilegenerator.py', file_name])
    
    # Close the UI
    root.destroy()

# Create a simple UI
def create_ui():
    def generate_button_click():
        file_type = file_type_var.get()
        generate_file(file_type, root)

    root = tk.Tk()
    root.title("File Generation UI")

    file_label = tk.Label(root, text="What file would you like to generate?")
    file_label.pack()

    file_options = ["QDOI", "QPAY", "MCOH", "QCNI", "QDOE", "QREV"]
    file_type_var = tk.StringVar(root)
    file_type_var.set(file_options[0])  # default value

    file_dropdown = ttk.Combobox(root, textvariable=file_type_var, values=file_options)
    file_dropdown.pack()

    generate_button = tk.Button(root, text="Generate File", command=generate_button_click)
    generate_button.pack()

    root.mainloop()

# Run the UI
create_ui()
