import tkinter as tk
from tkinter import scrolledtext, messagebox
import json

class LengthsLoader:
    def __init__(self):
     with open("filename.txt", 'r') as filename_file:
       file_name = filename_file.read().strip()


     self.file_name = file_name

    def read_lengths(self):
        try:
            with open(self.file_name, 'r') as file:
                lengths = json.load(file)
            return lengths.get("Header", {}), lengths.get("TransactionRecord", {}), lengths.get("TrailerRecord", {})
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            raise
        except FileNotFoundError:
            print(f"Error: File {self.file_name} not found.")
            raise
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
            raise

# Example usage
lengths_loader = LengthsLoader()
desired_lengths, desired_lengthss, desired_lengthsR = lengths_loader.read_lengths()

#print(desired_lengths)
#print(desired_lengthss)
#print(desired_lengthsR)


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("File Generator App")

        

        # List of frames for each step
        self.frames = [self.create_frame("Header", desired_lengths),
                       self.create_frame("TransactionRecord", desired_lengthss),
                       self.create_frame("TrailerRecord", desired_lengthsR)]

        # Index to track the current frame
        self.current_frame_index = 0

        # Create buttons for navigation
        self.back_button = tk.Button(root, text="Back", command=self.show_previous_frame)
        self.back_button.pack(side=tk.TOP, pady=5)
        self.next_button = tk.Button(root, text="Next", command=self.show_next_frame)
        self.next_button.pack(side=tk.TOP, pady=5)

        

    def create_frame(self, record_name, lengths):
        frame = tk.Frame(self.root)
        tk.Label(frame, text=f"{record_name} Data:").pack()

        for field, length in lengths.items():
            tk.Label(frame, text=field).pack()
            entry = tk.Entry(frame, width=40)
            entry.pack()
            setattr(self, f"{record_name}_{field}", entry)

        return frame

    def show_previous_frame(self):
        # Hide the current frame
        self.frames[self.current_frame_index].pack_forget()

        # Move to the previous frame
        self.current_frame_index -= 1

        # Show the previous frame
        self.frames[self.current_frame_index].pack()

        # Update button text for the last frame
        self.next_button.config(text="Next")

    def show_next_frame(self):
        # Hide the current frame
        self.frames[self.current_frame_index].pack_forget()

        # Move to the next frame
        self.current_frame_index += 1

        # If there are more frames, show the next one
        if self.current_frame_index < len(self.frames):
            self.frames[self.current_frame_index].pack()

            # Update button text for the last frame
            if self.current_frame_index == len(self.frames) - 1:
                self.next_button.config(text="Generate File", command=self.generate_file)
                self.generated_text.delete(1.0, tk.END)

                 
        else:
            messagebox.showinfo("Finished", "All data entered. Click 'Generate File' to proceed.")

    def generate_file(self):
        header_data = self.get_record_data("Header", desired_lengths)
        transaction_data = self.get_record_data("TransactionRecord", desired_lengthss)
        trailer_data = self.get_record_data("TrailerRecord", desired_lengthsR)

        filename = "GeneratedFile.txt"
        with open(filename, "w") as file:
            # Write the Header data
            for field_data in header_data:
                file.write(field_data)

            # Write the TransactionRecord data
            file.write("\n")
            for field_data in transaction_data:
                file.write(field_data)

            # Write the TrailerRecord data
            file.write("\n")
            for field_data in trailer_data:
                file.write(field_data)

        # Display the generated text in the scrolled text widget
        with open(filename, "r") as file:
            generated_text_content = file.read()
            self.generated_text.delete(1.0, tk.END)  # Clear previous content
            self.generated_text.insert(tk.END, generated_text_content)

    def get_record_data(self, record_name, lengths):
        record_data = ""
        frame = self.frames[self.current_frame_index]
        for field, length in lengths.items():
            field_data = getattr(self, f"{record_name}_{field}").get()
            field_data = field_data.ljust(length)

            if len(field_data) > length:
                messagebox.showerror("Error", f"You have exceeded the desired length for {field} length {length} on the {record_name}")

            record_data += field_data

        return record_data

# Create the main window
root = tk.Tk()
app = App(root)
app.frames[0].pack()  # Show the first frame initially
root.mainloop()
