package Tests;

import Common_Base.BrowserConfiguration;
import Common_Base.Report;
import Functionality.DemoBlazeObjects;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Random;

import static Common_Base.DataReader.readTestData;

public class DemoBlazeTest extends Report {
    WebDriver driver = BrowserConfiguration.startBrowser("chrome", "https://www.demoblaze.com/");
    DemoBlazeObjects demoBlazeObjects = PageFactory.initElements(driver, DemoBlazeObjects.class);

    String password = "Password" + new Random().ints(7, 0, 10)
            .collect(StringBuilder::new, StringBuilder::append, StringBuilder::append)
            .toString();

    String username = "Username" + new Random().ints(7, 0, 10)
            .collect(StringBuilder::new, StringBuilder::append, StringBuilder::append)
            .toString();


    @Test(description = ": As a new customer I want to create a new account for myself so that I can make online \n" +
            "purchases")
    public void asignUp() throws IOException, InterruptedException {
        test = extent.createTest("Signing up to Demo Blaze");

        //Taking Screenshot on Home Page
        TakeScreeshot(driver, "Home Page");
        demoBlazeObjects.SignUp(username, password);
        TakeScreeshot(driver, "Sign Up");

    }

    @Test(description = "As a registered customer I want to add the following items to the shipping cart so that I can \n" +
            "proceed to checkout")
    public void bParchaseProducts() throws IOException, InterruptedException {
        //test = extent.createTest("Sending Contact Details");
        //Taking Screenshot on Home Page
        test = extent.createTest("Logging In to Demo Blaze");
        demoBlazeObjects.SignIn(password, username);
        TakeScreeshot(driver, "Log in");

        test = extent.createTest("adding products in cart");
        demoBlazeObjects.AddProductsToCart();
        TakeScreeshot(driver, "Adding Products to cart");

        test = extent.createTest("clearing products in the cart ");
        demoBlazeObjects.ClearCart();
        TakeScreeshot(driver, "Clearing cart");

        test = extent.createTest("Placing order for the products in the cart");
        demoBlazeObjects.PlaceOrder();
        TakeScreeshot(driver, "Placing an order with products in cart");

    }






    //Screenshot Method
    public static String TakeScreeshot(WebDriver driver,String screenshotName)
    {
        TakesScreenshot ts =(TakesScreenshot) driver;
        File src = ts.getScreenshotAs(OutputType.FILE);

        String path =System.getProperty("user.dir")+"/Screenshots/"+screenshotName+".png";

        File destination = new File(path);

        try {
            FileUtils.copyFile(src,destination);
        }catch (IOException e)
        {
            System.out.println("Capture Failed "+e.getMessage());
        }
        return path;
    }
    //Closing Web Browser
    @AfterClass
    public void closeBrowser() {
        driver.close();
        driver.quit();

    }

}
