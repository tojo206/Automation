package Common_Base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrowserConfiguration {
    static WebDriver driver;

    public static WebDriver startBrowser(String browserchoice,String url) {
        if ("edge".equals(browserchoice)) {

            WebDriverManager.edgedriver().setup();

            driver = new EdgeDriver();
        } else if ("chrome".equals(browserchoice)) {

          WebDriverManager.chromedriver().setup();

          driver =new ChromeDriver();
        }
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        driver.manage().window().maximize();
        driver.get(url);
        return driver;



    }
}
