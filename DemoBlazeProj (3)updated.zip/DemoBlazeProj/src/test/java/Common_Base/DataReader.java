package Common_Base;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
public class DataReader {

    public static Map<String, String> readTestData(String filePath, String sheetName) {
        Map<String, String> testData = new HashMap<>();
        FileInputStream inputStream = null;
        Workbook workbook = null;
        try {
            // Load the Excel file
            inputStream = new FileInputStream(filePath);
            workbook = WorkbookFactory.create(inputStream);

            // Get the sheet
            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new IllegalArgumentException("Sheet '" + sheetName + "' not found.");
            }

            // Find the header row to determine column indices
            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                throw new IllegalArgumentException("Header row not found in sheet '" + sheetName + "'.");
            }

            // Find column indices for username, password, and email
            int DeviceTypeIndex = findColumnIndex(headerRow, "DeviceType");
            int QuantityIndex = findColumnIndex(headerRow, "Quantity");
            int DeviceNameIndex = findColumnIndex(headerRow, "DeviceName");

            // Iterate through rows to read data
            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // Skip header row

                String deviceType = getCellValue(row.getCell(DeviceTypeIndex));
                String quantity = getCellValue(row.getCell(QuantityIndex));
                String deviceName = getCellValue(row.getCell(DeviceNameIndex));

                // Add data to the map
                testData.put(deviceType, deviceName + ":" + quantity);
            }
        } catch (IOException | InvalidFormatException e) {
            e.printStackTrace();
        } finally {
            try {
                if (workbook != null) workbook.close();
                if (inputStream != null) inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return testData;
    }

    private static int findColumnIndex(Row headerRow, String columnName) {
        for (Cell cell : headerRow) {
            if (getCellValue(cell).equalsIgnoreCase(columnName)) {
                return cell.getColumnIndex();
            }
        }
        throw new IllegalArgumentException("Column '" + columnName + "' not found in header row.");
    }

    private static String getCellValue(Cell cell) {
        if (cell == null) return ""; // Return an empty string for null cells
        // Always return a string representation of the cell's value
        return cell.toString();
    }

    // Example usage

    }

