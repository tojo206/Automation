package Functionality;

import Common_Base.DataReader;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;

import static Common_Base.DataReader.readTestData;

public class DemoBlazeObjects {

    WebDriver driver;

    String DummyData = "DummyVal" + new Random().ints(7, 0, 10)
            .collect(StringBuilder::new, StringBuilder::append, StringBuilder::append)
            .toString();

    DataReader readTestData = new DataReader();

    public DemoBlazeObjects(WebDriver driver) {
        this.driver = driver;
    }

    @FindBy(id = "signin2")
    WebElement signUp;

    @FindBy(id = "sign-username")
    WebElement signUpUsername;

    @FindBy(id = "sign-password")
    WebElement signUpPassword;

    @FindBy(xpath = "//button[@class='btn btn-primary' and text()='Sign up']")
    WebElement signUpButton;

    @FindBy(id = "login2")
    WebElement SignIn;
    @FindBy(id = "loginusername")
    WebElement loginUsername;
    @FindBy(id = "loginpassword")
    WebElement loginPassword;

    @FindBy(xpath = "//button[text()='Log in']")
    WebElement loginButton;

    @FindBy(id  = "nameofuser")
    WebElement WelcomeMessage;



    @FindBy(xpath =  "//*[@id=\"itemc\"][1]")
    WebElement Phones;

    @FindBy(xpath = "//*[@id=\"itemc\"][3]")
    WebElement Monitors;



    @FindBy(xpath  = "//a[text()=\"Add to cart\"]")
    WebElement AddToCart;


    @FindBy(xpath = "//*[@id=\"navbarExample\"]/ul/li[1]/a")
    WebElement home;


    @FindBy(xpath = "//*[@id=\"navbarExample\"]/ul/li[4]/a")
    WebElement Cart;

    @FindBy(id= "totalp")
    WebElement CartTotal;

    @FindBy(xpath= "//input[@type=\"text\" and @class=\"form-control\" and @id=\"name\"]")
    WebElement name;
    @FindBy(xpath= "//input[@type=\"text\" and @class=\"form-control\" and @id=\"country\"]")
    WebElement country;
    @FindBy(xpath= "//input[@type=\"text\" and @class=\"form-control\" and @id=\"city\"]")
    WebElement city;
    @FindBy(xpath= "//input[@type=\"text\" and @class=\"form-control\" and @id=\"card\"]")
    WebElement credit;
    @FindBy(xpath= "//input[@type=\"text\" and @class=\"form-control\" and @id=\"month\"]")
    WebElement month;
    @FindBy(xpath= "//input[@type=\"text\" and @class=\"form-control\" and @id=\"year\"]")
    WebElement year;
    @FindBy(xpath= "//button[@type=\"button\" and @onclick=\"purchaseOrder()\"]")
    WebElement purchaseOrderButton;

    @FindBy(xpath= "//button[@class=\"btn btn-success\" and @data-toggle=\"modal\"]\n")
    WebElement PlaceOrder;



    /*
     * Method to sign up a new user with provided username and password.
     * If the user already exists, it handles the alert and retries signing up.
     */
    public void SignUp(String username, String password) throws InterruptedException {
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(signUp)).click();
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(signUpUsername)).sendKeys(username);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(signUpPassword)).sendKeys(password);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(signUpButton)).click();

        WebDriverWait wait = new WebDriverWait(driver, 40);
        Alert alert = wait.until(ExpectedConditions.alertIsPresent());
        String alertText = alert.getText();
        try {
            if (Objects.equals(alertText, "This user already exist.")) {
                SignUp(username, password);
                System.out.println(alertText);
            } else {
                System.out.println(alertText);
            }
            alert.accept();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    /*
     * Method to sign in with provided username and password.
     * it iterates through the pages using the user created
     */
    public void SignIn(String password, String username) throws InterruptedException {
        Thread.sleep(2000);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(SignIn)).click();
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(loginUsername)).sendKeys(username);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(loginPassword)).sendKeys(password);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(loginButton)).click();

        Thread.sleep(3000);
        try {
            new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(WelcomeMessage)).getText();


        } catch (Exception e) {
            System.out.println("User Not Logged in");
            throw new RuntimeException(e);

        }

    }

    /*
     * Method to add products to cart by clicking on Monitors and Phones,
     * selecting specific products, and adding them to the cart.
     */
    public void AddProductsToCart() throws InterruptedException {

        String filePath = "C:\\Users\\Paballo.Nkuna\\Downloads\\DemoBlazeProj\\src\\test\\java\\Common_Base\\test_data.xlsx";
        String sheetName = "TestData";
        //DataReader reader = new DataReader();
        Map<String, String> testData = readTestData(filePath, sheetName);
        testData.forEach((deviceType, data) -> {
            String[] parts = data.split(":");
            String deviceName = parts[0];
            String quantity = parts[1];

            if (Objects.equals(deviceType, "Monitor") ){


                //System.out.println(monitor);
                double val = Double.parseDouble(quantity);
                int intQuantity = (int) val;

                    for (int j = 0; j < intQuantity; j++) {

                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }

                        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(Monitors)).click();

                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        WebElement device = driver.findElement(By.xpath("//a[@class=\"hrefch\" and text()=\""+deviceName+"\"]"));



                        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(device)).click();
                        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(AddToCart)).click();
                        WebDriverWait wait = new WebDriverWait(driver, 40);
                        Alert alert = wait.until(ExpectedConditions.alertIsPresent());
                        alert.accept();


                        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(home)).click();

                    }

                } else if (Objects.equals(deviceType, "Phone")) {


                //System.out.println(monitor);



                double val = Double.parseDouble(quantity);
                int intQuantity = (int) val;

                    for (int j = 0; j < intQuantity; j++) {

                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }

                        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(Phones)).click();

                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        WebElement device = driver.findElement(By.xpath("//a[@class=\"hrefch\" and text()=\""+deviceName+"\"]"));

                        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(device)).click();
                        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(AddToCart)).click();
                        WebDriverWait wait = new WebDriverWait(driver, 40);
                        Alert alert = wait.until(ExpectedConditions.alertIsPresent());
                        alert.accept();
                        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(home)).click();
                    }

                }



        });

    }

    /*
     * Method to clear the cart by navigating to the cart page,
     * calculating the total price, validating it, and placing the order.
     */
    public void ClearCart() throws InterruptedException {
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(Cart)).click();

        Thread.sleep(4000);
        List<WebElement> elements = driver.findElements(By.xpath("//tr[@class='success']/td[3]"));

        int Total = 0;
        for (WebElement ValueElements : elements) {
            String prices = ValueElements.getText();
            int intPrices = Integer.parseInt(prices);
            Total = Total + intPrices;
        }

        String TotalVal = new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(CartTotal)).getText();
        int intCartPrice = Integer.parseInt(TotalVal);

        Assert.assertEquals(intCartPrice, Total);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(PlaceOrder)).click();

    }

    /*
     * Method to place an order by filling in the required details with dummy data.
     */
    public void PlaceOrder() {
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(name)).sendKeys(DummyData);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(country)).sendKeys(DummyData);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(city)).sendKeys(DummyData);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(credit)).sendKeys(DummyData);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(month)).sendKeys(DummyData);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(year)).sendKeys(DummyData);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(purchaseOrderButton)).click();


    }
}


