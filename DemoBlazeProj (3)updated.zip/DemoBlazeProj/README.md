### Demo Blaze assessment
##### Step by step configuration

### Pre-requisite
##### Must Have java 8 installed
##### must have IntelliJ installed
##### Must have Chrome Web-Browser installed

### Dependencies
##### the project is build using Maven dependencies, all required dependencies already included on the project inside pom.xml file

### After Cloning the project
##### Import or open on Intellij
##### You will  notice that the dependencies will start downloading(give it some time for it to complete downloading)

### Executing way to run the tests
##### Open the test class and click run(execution will start)
##### Once execution is done, check reports and screenshot on directories on the project in IntelliJ


