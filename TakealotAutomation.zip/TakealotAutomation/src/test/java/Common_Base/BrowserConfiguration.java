package Common_Base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrowserConfiguration {

    public static String dir = System.getProperty("user.dir");



    static WebDriver driver;

    public static WebDriver startBrowser(String browserchoice,String url) {
        if ("edge".equals(browserchoice)) {

            WebDriverManager.edgedriver().setup();

            driver = new EdgeDriver();
        } else if ("chrome".equals(browserchoice)) {
           WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
        }
        driver.manage().window().maximize();
        driver.get(url);
        return driver;



    }
}
