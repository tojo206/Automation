package Tests;

import Common_Base.BrowserConfiguration;
import Common_Base.Report;
import Functionality.TakelotObjects;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

public class TakeAlotTest extends Report {

    //Launching URL
    WebDriver driver = BrowserConfiguration.startBrowser("chrome"," https://www.takealot.com/");

    TakelotObjects takelotObjects = PageFactory.initElements(driver, TakelotObjects.class);

    @Test(description = "Adding Product to the cart")
    public void AddingProductsToCart() throws IOException, InterruptedException {
        test = extent.createTest("Sending Contact Details");

        //Taking Screenshot on Home Page
        TakeScreeshot(driver,"Home Page");
        takelotObjects.setSearchbar("inverter");
        takelotObjects.ClickProduct();
        TakeScreeshot(driver,"products page");
        takelotObjects.ClickCart();
        TakeScreeshot(driver,"CartPage page");
        takelotObjects.Checkout();

    }
    //Screenshot Method
    public static String TakeScreeshot(WebDriver driver,String screenshotName)
    {
        TakesScreenshot ts =(TakesScreenshot) driver;
        File src = ts.getScreenshotAs(OutputType.FILE);

        String path =System.getProperty("user.dir")+"/Screenshots/"+screenshotName+".png";

        File destination = new File(path);

        try {
            FileUtils.copyFile(src,destination);
        }catch (IOException e)
        {
            System.out.println("Capture Failed "+e.getMessage());
        }
        return path;
    }
    //Closing Web Browser
    @AfterClass
    public void closeBrowser() {
        driver.quit();
    }

}
