package Functionality;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TakelotObjects {

    WebDriver driver;

    public TakelotObjects(WebDriver driver) {
        this.driver = driver;
    }

    String Script = "arguments[0].scrollIntoView();";
    // finding elements using Page Factory
    @FindBy(xpath = "//input[@name='search']")
    WebElement Searchbar;

    @FindBy(xpath = "//button[@class='button  expanded add-to-cart-button add-to-cart-button-module_add-to-cart-button_1a9gT ghost']")
    WebElement product;

    @FindBy(xpath = "//button[@class='button badge-button mini-cart-button dark-green  badge-button-module_badge-button_3TXVp badge-button-module_badge-icon_LvKrF badge-button-module_badge-count_28PIS']")
    WebElement clickCart;

    @FindBy(xpath = "//a[@class='button pay checkout-button cart-summary-module_proceed-to-checkout-btn_3tQOD checkout-button-module_checkout-button_3B_QV']")
    WebElement clickCheckout;


    public void setSearchbar(String productName) throws InterruptedException {
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(Searchbar)).click();
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(Searchbar)).sendKeys(productName);
        Thread.sleep(2000);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(Searchbar)).sendKeys(Keys.RETURN);
    }


    //Click on Cart logo to open Cart
    public void ClickProduct() throws InterruptedException {

        ((JavascriptExecutor) driver).executeScript(Script, product);
        Thread.sleep(5000);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(product)).click();

    }


    //Click Checkout Button
    public void ClickCart() throws InterruptedException {

        Thread.sleep(2000);
        ((JavascriptExecutor) driver).executeScript(Script, clickCart);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(clickCart)).click();

    }

    public void Checkout() throws InterruptedException {

        Thread.sleep(2000);
        new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(clickCheckout)).click();

    }




}
