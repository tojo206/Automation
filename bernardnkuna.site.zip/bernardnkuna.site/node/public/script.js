document.addEventListener("DOMContentLoaded", () => {
    const verifyButton = document.getElementById("verifyButton");
    const voucherInput = document.getElementById("voucherInput");
    const message = document.getElementById("message");

    verifyButton.addEventListener("click", () => {
        const voucherToken = voucherInput.value.trim();
        if (voucherToken === "") {
            message.textContent = "Please enter a voucher token.";
            return;
        }

        // Send a POST request to the server for verification
        fetch("/verify-voucher", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ token: voucherToken }),
        })
        .then((response) => response.json())
        .then((data) => {
            message.textContent = data.message;
        })
        .catch((error) => {
            console.error(error);
            message.textContent = "An error occurred.";
        });
    });
});
