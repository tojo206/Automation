const express = require('express');
const app = express();
const port = 3000;

// Serve static files from the 'public' folder
app.use(express.static('public'));

app.post('/verify-voucher', (req, res) => {
  const voucherToken = req.body.token;

  // Read the TXT file and check if the voucher exists
  fs.readFile('public/verify-voucher.txt', 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ message: 'Internal server error' });
    }

    const vouchers = data.split('\n');
    const index = vouchers.indexOf(voucherToken);

    if (index !== -1) {
      // Voucher found, remove it from the file
      vouchers.splice(index, 1);
      const updatedVouchers = vouchers.join('\n');
      fs.writeFile('/verify-voucher.txt', updatedVouchers, (err) => {
        if (err) {
          return res.status(500).json({ message: 'Internal server error' });
        }
        return res.json({ message: 'Voucher loaded successfully' });
      });
    } else {
      // Voucher not found
      return res.status(404).json({ message: 'Voucher invalid' });
    }
  });
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});